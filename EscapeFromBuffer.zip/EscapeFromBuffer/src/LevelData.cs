using System.Collections.Generic;
  using System.Drawing;

  namespace EscapeFromBuffer
  {
      internal enum PlatformStyle { Metal, Glowing, Ice, Lava, Circuit }
      internal enum EnemyKind    { Bug, Virus, Drone }

      internal struct PlatformDef
      {
          public float X, Y, W, H;
          public PlatformStyle Style;
          public PlatformDef(float x, float y, float w, float h, PlatformStyle s = PlatformStyle.Metal)
          { X=x; Y=y; W=w; H=h; Style=s; }
          public RectangleF Rect => new RectangleF(X, Y, W, H);
      }

      internal struct EnemySpawnDef
      {
          public float X, Y, Min, Max;
          public bool Horiz;
          public EnemyKind Kind;
          public EnemySpawnDef(float x, float y, float min, float max, bool horiz, EnemyKind k)
          { X=x; Y=y; Min=min; Max=max; Horiz=horiz; Kind=k; }
      }

      internal struct CoinDef { public float X, Y; public CoinDef(float x, float y){X=x;Y=y;} }

      internal class LevelData
      {
          public int    Number;
          public string Name  = "";
          public int    WorldW = 3200;
          public int    WorldH = 560;
          public float  SpawnX = 60f;
          public float  SpawnY = 400f;
          public RectangleF Portal;
          public Color  SkyTop, SkyBot;
          public Color  PlatformAccent;
          public List<PlatformDef>   Platforms  = new List<PlatformDef>();
          public List<EnemySpawnDef> EnemyDefs  = new List<EnemySpawnDef>();
          public List<CoinDef>       CoinDefs   = new List<CoinDef>();
      }
  }