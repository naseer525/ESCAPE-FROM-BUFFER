using System.Drawing;

  namespace EscapeFromBuffer
  {
      internal static class LevelBuilder
      {
          public static LevelData Build(int n)
          {
              switch(n)
              {
                  case 2: return Level2();
                  case 3: return Level3();
                  case 4: return Level4();
                  default: return Level1();
              }
          }

          // ── LEVEL 1  "The Firewall" ───────────────────────────────────
          // Theme: cyberpunk green, stepping-stone intro
          static LevelData Level1()
          {
              var d = new LevelData
              {
                  Number       = 1,
                  Name         = "The Firewall",
                  WorldW       = 3200,
                  SpawnX       = 60f, SpawnY = 400f,
                  Portal       = new RectangleF(3070f, 350f, 60f, 110f),
                  SkyTop       = Color.FromArgb(0, 5, 0),
                  SkyBot       = Color.FromArgb(0, 28, 8),
                  PlatformAccent = Color.FromArgb(0, 220, 80)
              };

              // Ground
              d.Platforms.Add(new PlatformDef(0, 480, 3200, 80, PlatformStyle.Circuit));

              // Stepping platforms
              Add(d, 180,  410, 130, 18, PlatformStyle.Metal);
              Add(d, 380,  360, 110, 18, PlatformStyle.Metal);
              Add(d, 560,  300, 130, 18, PlatformStyle.Glowing);
              Add(d, 740,  360, 110, 18, PlatformStyle.Metal);
              Add(d, 920,  420, 150, 18, PlatformStyle.Metal);
              Add(d, 1110, 350, 110, 18, PlatformStyle.Metal);
              Add(d, 1290, 270, 130, 18, PlatformStyle.Glowing);
              Add(d, 1470, 350, 110, 18, PlatformStyle.Metal);
              Add(d, 1660, 420, 140, 18, PlatformStyle.Metal);
              Add(d, 1840, 360, 120, 18, PlatformStyle.Metal);
              Add(d, 2020, 280, 110, 18, PlatformStyle.Glowing);
              Add(d, 2200, 360, 130, 18, PlatformStyle.Metal);
              Add(d, 2390, 280, 130, 18, PlatformStyle.Metal);
              Add(d, 2580, 200, 110, 18, PlatformStyle.Glowing);
              Add(d, 2760, 280, 120, 18, PlatformStyle.Metal);
              Add(d, 2940, 360, 130, 18, PlatformStyle.Metal);
              Add(d, 3060, 460, 140, 18, PlatformStyle.Metal); // near exit ground

              // Enemies
              E(d, 560,  262, 560, 690,  true,  EnemyKind.Bug);
              E(d, 920,  382, 920, 1070, true,  EnemyKind.Bug);
              E(d, 1290, 232, 1290,1420, true,  EnemyKind.Bug);
              E(d, 2020, 242, 2020,2130, true,  EnemyKind.Virus);
              E(d, 2580, 162, 150, 480,  false, EnemyKind.Drone);

              // Coins scattered on platforms and in air
              Coins(d,
                  230,390,  280,390,  330,390,
                  430,340,  480,340,
                  600,280,  660,280,
                  790,340,  840,340,
                  970,400,  1020,400, 1070,400,
                  1160,330, 1210,330,
                  1340,250, 1390,250,
                  1720,400, 1770,400,
                  1890,340, 1940,340,
                  2070,260, 2120,260,
                  2440,260, 2500,260,
                  2630,180, 2680,180,
                  2810,260, 2860,260
              );
              return d;
          }

          // ── LEVEL 2  "The Virus Lab" ──────────────────────────────────
          // Theme: biohazard red-orange, more vertical
          static LevelData Level2()
          {
              var d = new LevelData
              {
                  Number       = 2,
                  Name         = "The Virus Lab",
                  WorldW       = 3400,
                  SpawnX       = 60f, SpawnY = 400f,
                  Portal       = new RectangleF(3270f, 310f, 60f, 110f),
                  SkyTop       = Color.FromArgb(12, 0, 0),
                  SkyBot       = Color.FromArgb(30, 5, 0),
                  PlatformAccent = Color.FromArgb(255, 90, 20)
              };
              d.Platforms.Add(new PlatformDef(0, 480, 3400, 80, PlatformStyle.Lava));

              // Zigzag layout
              Add(d, 200,  420, 120, 18, PlatformStyle.Metal);
              Add(d, 360,  350, 100, 18, PlatformStyle.Metal);
              Add(d, 500,  270, 130, 18, PlatformStyle.Lava);
              Add(d, 660,  200, 110, 18, PlatformStyle.Glowing);
              Add(d, 820,  270, 120, 18, PlatformStyle.Metal);
              Add(d, 980,  350, 110, 18, PlatformStyle.Metal);
              Add(d, 1130, 420, 130, 18, PlatformStyle.Metal);
              Add(d, 1310, 350, 110, 18, PlatformStyle.Metal);
              Add(d, 1480, 270, 120, 18, PlatformStyle.Lava);
              Add(d, 1660, 200, 110, 18, PlatformStyle.Glowing);
              Add(d, 1830, 140, 140, 18, PlatformStyle.Glowing);
              Add(d, 2000, 200, 110, 18, PlatformStyle.Metal);
              Add(d, 2160, 270, 120, 18, PlatformStyle.Metal);
              Add(d, 2330, 350, 110, 18, PlatformStyle.Metal);
              Add(d, 2490, 270, 130, 18, PlatformStyle.Lava);
              Add(d, 2660, 200, 110, 18, PlatformStyle.Glowing);
              Add(d, 2840, 130, 120, 18, PlatformStyle.Glowing);
              Add(d, 3020, 200, 120, 18, PlatformStyle.Metal);
              Add(d, 3170, 280, 140, 18, PlatformStyle.Metal);

              E(d, 500, 232, 500, 630, true,  EnemyKind.Bug);
              E(d, 820, 232, 820, 940, true,  EnemyKind.Virus);
              E(d, 1480,232, 1480,1610,true,  EnemyKind.Bug);
              E(d, 1830,102, 1830,1970,true,  EnemyKind.Virus);
              E(d, 660, 150, 150, 480, false, EnemyKind.Drone);
              E(d, 2660,150, 150, 480, false, EnemyKind.Drone);
              E(d, 2490,232, 2490,2620,true,  EnemyKind.Virus);

              Coins(d,
                  250,400, 300,400,
                  410,330, 460,330,
                  550,250, 600,250, 630,250,
                  710,180, 760,180,
                  870,250, 920,250,
                  1030,330,1080,330,
                  1360,330,1410,330,
                  1530,250,1580,250,
                  1710,180,1760,180,
                  1880,120,1930,120,1980,120,
                  2210,250,2260,250,
                  2540,250,2590,250,
                  2710,180,2760,180,
                  2890,110,2940,110,2990,110,
                  3070,180,3120,180
              );
              return d;
          }

          // ── LEVEL 3  "The Data Vault" ─────────────────────────────────
          // Theme: cold blue, multi-layered vertical
          static LevelData Level3()
          {
              var d = new LevelData
              {
                  Number       = 3,
                  Name         = "The Data Vault",
                  WorldW       = 3600,
                  SpawnX       = 60f, SpawnY = 400f,
                  Portal       = new RectangleF(3490f, 320f, 60f, 110f),
                  SkyTop       = Color.FromArgb(0, 0, 18),
                  SkyBot       = Color.FromArgb(0, 5, 35),
                  PlatformAccent = Color.FromArgb(40, 140, 255)
              };
              d.Platforms.Add(new PlatformDef(0, 480, 3600, 80, PlatformStyle.Ice));

              // Tiered with gaps requiring jumps + small ledges
              Add(d, 150, 430, 100, 18, PlatformStyle.Ice);
              Add(d, 300, 380, 80,  18, PlatformStyle.Ice);
              Add(d, 430, 320, 100, 18, PlatformStyle.Glowing);
              Add(d, 580, 260, 80,  18, PlatformStyle.Ice);
              Add(d, 710, 200, 100, 18, PlatformStyle.Glowing);
              Add(d, 860, 260, 80,  18, PlatformStyle.Ice);
              Add(d, 980, 320, 100, 18, PlatformStyle.Ice);
              Add(d, 1120,380, 80,  18, PlatformStyle.Ice);
              Add(d, 1240,430, 100, 18, PlatformStyle.Ice);
              Add(d, 1380,370, 80,  18, PlatformStyle.Ice);
              Add(d, 1510,300, 100, 18, PlatformStyle.Glowing);
              Add(d, 1660,230, 80,  18, PlatformStyle.Glowing);
              Add(d, 1800,160, 120, 18, PlatformStyle.Glowing);
              Add(d, 1970,220, 80,  18, PlatformStyle.Ice);
              Add(d, 2100,290, 100, 18, PlatformStyle.Ice);
              Add(d, 2250,360, 80,  18, PlatformStyle.Ice);
              Add(d, 2380,290, 100, 18, PlatformStyle.Glowing);
              Add(d, 2530,220, 80,  18, PlatformStyle.Glowing);
              Add(d, 2660,150, 110, 18, PlatformStyle.Glowing);
              Add(d, 2820,220, 80,  18, PlatformStyle.Ice);
              Add(d, 2960,290, 100, 18, PlatformStyle.Ice);
              Add(d, 3100,360, 80,  18, PlatformStyle.Ice);
              Add(d, 3240,290, 100, 18, PlatformStyle.Glowing);
              Add(d, 3390,360, 110, 18, PlatformStyle.Glowing);

              E(d, 430, 282, 430, 580, true,  EnemyKind.Virus);
              E(d, 710, 162, 710, 860, true,  EnemyKind.Drone);
              E(d, 1510,262, 1510,1660,true,  EnemyKind.Bug);
              E(d, 1800,122, 1800,1970,true,  EnemyKind.Virus);
              E(d, 2660,112, 150, 480, false, EnemyKind.Drone);
              E(d, 2380,252, 2380,2530,true,  EnemyKind.Virus);
              E(d, 3240,252, 3240,3390,true,  EnemyKind.Drone);
              E(d, 580, 180, 150, 480, false, EnemyKind.Drone);

              Coins(d,
                  175,410, 220,410,
                  320,360, 370,360,
                  460,300, 510,300,
                  610,240, 660,240,
                  740,180, 790,180, 840,180,
                  910,240, 960,240,
                  1040,300,1090,300,
                  1440,350,1490,350,
                  1550,280,1600,280,
                  1700,210,1750,210,
                  1840,140,1890,140,1940,140,
                  2020,200,2070,200,
                  2140,270,2190,270,
                  2430,270,2480,270,
                  2570,200,2620,200,
                  2700,130,2750,130,2800,130,
                  2870,200,2920,200,
                  3020,270,3070,270,
                  3280,270,3330,270,
                  3430,340,3480,340
              );
              return d;
          }

          // ── LEVEL 4  "The Core" (Boss level) ─────────────────────────
          // Theme: red warning, many enemies, hardest
          static LevelData Level4()
          {
              var d = new LevelData
              {
                  Number       = 4,
                  Name         = "The Core",
                  WorldW       = 3800,
                  SpawnX       = 60f, SpawnY = 400f,
                  Portal       = new RectangleF(3680f, 340f, 60f, 110f),
                  SkyTop       = Color.FromArgb(18, 0, 0),
                  SkyBot       = Color.FromArgb(40, 0, 0),
                  PlatformAccent = Color.FromArgb(255, 30, 30)
              };
              d.Platforms.Add(new PlatformDef(0, 480, 3800, 80, PlatformStyle.Lava));

              // Dense, punishing layout
              Add(d, 140, 420, 110, 18, PlatformStyle.Metal);
              Add(d, 290, 360, 90,  18, PlatformStyle.Metal);
              Add(d, 430, 300, 100, 18, PlatformStyle.Lava);
              Add(d, 580, 240, 90,  18, PlatformStyle.Glowing);
              Add(d, 720, 180, 110, 18, PlatformStyle.Glowing);
              Add(d, 880, 240, 90,  18, PlatformStyle.Metal);
              Add(d, 1020,300, 100, 18, PlatformStyle.Metal);
              Add(d, 1170,360, 90,  18, PlatformStyle.Metal);
              Add(d, 1310,300, 100, 18, PlatformStyle.Lava);
              Add(d, 1460,240, 90,  18, PlatformStyle.Glowing);
              Add(d, 1600,170, 110, 18, PlatformStyle.Glowing);
              Add(d, 1760,240, 90,  18, PlatformStyle.Metal);
              Add(d, 1900,310, 100, 18, PlatformStyle.Metal);
              Add(d, 2060,380, 90,  18, PlatformStyle.Metal);
              Add(d, 2200,310, 100, 18, PlatformStyle.Lava);
              Add(d, 2360,240, 90,  18, PlatformStyle.Glowing);
              Add(d, 2500,170, 110, 18, PlatformStyle.Glowing);
              Add(d, 2660,100, 100, 18, PlatformStyle.Glowing);
              Add(d, 2820,170, 90,  18, PlatformStyle.Metal);
              Add(d, 2960,240, 100, 18, PlatformStyle.Metal);
              Add(d, 3110,310, 90,  18, PlatformStyle.Metal);
              Add(d, 3260,380, 110, 18, PlatformStyle.Lava);
              Add(d, 3400,310, 100, 18, PlatformStyle.Metal);
              Add(d, 3550,380, 110, 18, PlatformStyle.Glowing);

              // Many enemies
              E(d, 430, 262, 430, 580, true,  EnemyKind.Virus);
              E(d, 720, 142, 720, 880, true,  EnemyKind.Drone);
              E(d, 1020,262, 1020,1170,true,  EnemyKind.Bug);
              E(d, 1310,262, 1310,1460,true,  EnemyKind.Virus);
              E(d, 1600,132, 1600,1760,true,  EnemyKind.Drone);
              E(d, 2200,272, 2200,2360,true,  EnemyKind.Bug);
              E(d, 2500,132, 2500,2660,true,  EnemyKind.Virus);
              E(d, 2660,62,  2660,2820,true,  EnemyKind.Drone);
              E(d, 580, 180, 150, 480, false, EnemyKind.Drone);
              E(d, 1760,180, 150, 480, false, EnemyKind.Drone);
              E(d, 3110,272, 3110,3260,true,  EnemyKind.Virus);
              E(d, 3400,272, 3400,3550,true,  EnemyKind.Drone);

              Coins(d,
                  190,400, 240,400,
                  330,340, 380,340,
                  470,280, 520,280,
                  620,220, 670,220,
                  760,160, 810,160, 860,160,
                  930,220, 980,220,
                  1070,280,1120,280,
                  1360,280,1410,280,
                  1500,220,1550,220,
                  1650,150,1700,150,1750,150,
                  1810,220,1860,220,
                  1950,290,2000,290,
                  2250,290,2300,290,
                  2410,220,2460,220,
                  2550,150,2600,150,
                  2710,80, 2760,80, 2810,80,
                  2870,150,2920,150,
                  3160,290,3210,290,
                  3310,360,3360,360,
                  3450,290,3500,290,
                  3600,360,3650,360
              );
              return d;
          }

          static void Add(LevelData d, float x, float y, float w, float h, PlatformStyle s)
              => d.Platforms.Add(new PlatformDef(x, y, w, h, s));

          static void E(LevelData d, float x, float y, float min, float max, bool h, EnemyKind k)
              => d.EnemyDefs.Add(new EnemySpawnDef(x, y, min, max, h, k));

          static void Coins(LevelData d, params float[] xy)
          {
              for (int i = 0; i + 1 < xy.Length; i += 2)
                  d.CoinDefs.Add(new CoinDef(xy[i], xy[i+1]));
          }
      }
  }