using System;
  using System.Collections.Generic;
  using System.Drawing;

  namespace EscapeFromBuffer
  {
      internal class GameEngine
      {
          // ── Sub-systems ───────────────────────────────────────────────
          public Player        Player   { get; private set; }
          public LevelData     Level    { get; private set; }
          public List<Enemy>   Enemies  { get; } = new List<Enemy>();
          public List<Coin>    Coins    { get; } = new List<Coin>();
          public List<Bullet>  Bullets  { get; } = new List<Bullet>();
          public List<Particle> Particles{ get; } = new List<Particle>();

          // ── State machine ─────────────────────────────────────────────
          public GameState State   { get; private set; } = GameState.Menu;
          public int CurrentLevel  { get; private set; } = 1;
          public string Overlay   { get; private set; } = "";
          public int  Tick        { get; private set; }

          private int _stateTimer;
          private readonly Random _rnd = new Random();

          // ── API ───────────────────────────────────────────────────────
          public void GoMenu()         { State = GameState.Menu; }
          public void GoInstructions() { State = GameState.Instructions; }
          public void GoLevelSelect()  { State = GameState.LevelSelect; }

          public void StartGame(int level = 1)
          {
              CurrentLevel = level;
              Player = new Player(60f, 400f);
              Player.FullReset();
              LoadLevel(level);
              State = GameState.Playing;
          }

          // ── Main update (called every 16 ms) ─────────────────────────
          public void Update(bool kLeft, bool kRight, bool kJump, bool kFire, bool kEsc)
          {
              Tick++;

              switch (State)
              {
                  case GameState.Playing:
                      if (kEsc) { State = GameState.Menu; return; }
                      UpdatePlaying(kLeft, kRight, kJump, kFire);
                      break;

                  case GameState.PlayerHit:
                      if (--_stateTimer <= 0)
                      {
                          Player.Respawn(Level.SpawnX, Level.SpawnY);
                          State = GameState.Playing;
                      }
                      break;

                  case GameState.LevelComplete:
                      if (--_stateTimer <= 0)
                      {
                          if (CurrentLevel < 4) { CurrentLevel++; StartGame(CurrentLevel); }
                          else                  { State = GameState.Victory; }
                      }
                      break;
              }

              // Always update particles
              for (int i = Particles.Count - 1; i >= 0; i--)
              {
                  Particles[i].Update();
                  if (!Particles[i].Alive) Particles.RemoveAt(i);
              }
          }

          // ── Core gameplay tick ────────────────────────────────────────
          private bool _jumpConsumed;

          private void UpdatePlaying(bool kLeft, bool kRight, bool kJump, bool kFire)
          {
              // ── Player movement ───────────────────────────────────────
              Player.VX = 0;
              if (kLeft)  { Player.VX = -Player.MoveSpeed; Player.FacingRight = false; }
              if (kRight) { Player.VX =  Player.MoveSpeed; Player.FacingRight = true;  }

              // Jump
              if (kJump && !_jumpConsumed && Player.OnGround)
              {
                  Player.VY = Player.JumpForce;
                  Player.OnGround = false;
                  _jumpConsumed = true;
                  SpawnParticles(Player.X + Player.W/2, Player.Y + Player.H,
                                 Color.FromArgb(0, 200, 80), 6, 2f);
              }
              if (!kJump) _jumpConsumed = false;

              // Fire
              if (kFire && Player.ShootCooldown <= 0)
              {
                  float bx = Player.FacingRight ? Player.X + Player.W : Player.X - Bullet.W;
                  float by = Player.Y + Player.H * 0.4f;
                  float vx = Player.FacingRight ? 14f : -14f;
                  Bullets.Add(new Bullet(bx, by, vx, 0, true));
                  Player.ShootCooldown = 14;
                  SpawnParticles(bx, by + Bullet.H/2,
                                 Color.FromArgb(60, 220, 255), 4, 1.5f);
              }

              // ── Physics ───────────────────────────────────────────────
              Player.VY += Player.GravityVal;
              if (Player.VY > Player.MaxFall) Player.VY = Player.MaxFall;

              MoveAndCollide(Player);
              Player.Update();

              // ── Enemies ───────────────────────────────────────────────
              foreach (var e in Enemies) e.Update();

              // Drone shoots
              foreach (var e in Enemies)
              {
                  if (!e.Active || e.Kind != EnemyKind.Drone) continue;
                  if (e.ShootTimer % 90 == 0)
                  {
                      float dx = (Player.X + Player.W/2) - (e.X + e.W/2);
                      float dy = (Player.Y + Player.H/2) - (e.Y + e.H/2);
                      float len = (float)Math.Sqrt(dx*dx+dy*dy);
                      if (len > 0 && len < 500)
                      {
                          dx /= len; dy /= len;
                          Bullets.Add(new Bullet(e.X+e.W/2, e.Y+e.H/2, dx*7f, dy*7f, false));
                      }
                  }
              }

              // ── Bullets ───────────────────────────────────────────────
              for (int i = Bullets.Count-1; i >= 0; i--)
              {
                  var b = Bullets[i];
                  b.Update(Level.WorldW);
                  if (!b.Active) { Bullets.RemoveAt(i); continue; }

                  // Wall check
                  if (HitsWall(b.X + (b.VX > 0 ? Bullet.W : 0), b.Y + Bullet.H/2))
                  { SpawnParticles(b.X, b.Y, Color.FromArgb(255,220,60), 5, 2f); Bullets.RemoveAt(i); continue; }

                  if (b.FromPlayer)
                  {
                      bool removed = false;
                      foreach (var e in Enemies)
                      {
                          if (!e.Active) continue;
                          if (b.Bounds.IntersectsWith(e.Bounds))
                          {
                              e.TakeDamage();
                              SpawnParticles(b.X, b.Y, Color.FromArgb(255, 80, 30), 8, 3f);
                              if (!e.Active) { Player.Score += 50; SpawnEnemyDeath(e); }
                              Bullets.RemoveAt(i); removed = true; break;
                          }
                      }
                      if (removed) continue;
                  }
                  else
                  {
                      // Enemy bullet hits player
                      if (!Player.IsInvincible && b.Bounds.IntersectsWith(Player.Bounds))
                      {
                          HitPlayer(); Bullets.RemoveAt(i); continue;
                      }
                  }
              }

              // ── Coins ─────────────────────────────────────────────────
              foreach (var c in Coins)
              {
                  if (c.Collected) continue;
                  c.Update();
                  if (Player.Bounds.IntersectsWith(c.Bounds))
                  {
                      c.Collected = true;
                      Player.Score += 10;
                      SpawnParticles(c.X, c.Y, Color.FromArgb(255, 215, 0), 10, 3f);
                  }
              }

              // ── Enemy body collision ──────────────────────────────────
              if (!Player.IsInvincible)
              {
                  foreach (var e in Enemies)
                  {
                      if (!e.Active) continue;
                      if (Player.Bounds.IntersectsWith(e.Bounds)) { HitPlayer(); break; }
                  }
              }

              // ── Portal (exit) ─────────────────────────────────────────
              if (Player.Bounds.IntersectsWith(Level.Portal))
              {
                  Overlay = CurrentLevel < 4
                      ? $"Level {CurrentLevel} Complete!"
                      : "YOU ESCAPED THE BUFFER!";
                  _stateTimer = 180;
                  State = GameState.LevelComplete;
              }

              // ── Fell off world ────────────────────────────────────────
              if (Player.Y > Level.WorldH + 100) HitPlayer();
          }

          // ── Collision helpers ─────────────────────────────────────────
          private void MoveAndCollide(Player p)
          {
              // Horizontal
              p.X += p.VX;
              p.X = Math.Max(0, Math.Min(p.X, Level.WorldW - Player.W));
              foreach (var plat in Level.Platforms)
              {
                  var pr = plat.Rect;
                  if (p.Bounds.IntersectsWith(pr))
                  {
                      if (p.VX > 0) p.X = pr.Left - Player.W;
                      else          p.X = pr.Right;
                      p.VX = 0;
                  }
              }

              // Vertical
              p.OnGround = false;
              p.Y += p.VY;
              foreach (var plat in Level.Platforms)
              {
                  var pr = plat.Rect;
                  if (p.Bounds.IntersectsWith(pr))
                  {
                      if (p.VY > 0)
                      {
                          p.Y = pr.Top - Player.H;
                          p.VY = 0;
                          p.OnGround = true;
                      }
                      else if (p.VY < 0)
                      {
                          p.Y = pr.Bottom;
                          p.VY = 0;
                      }
                  }
              }
          }

          private bool HitsWall(float bx, float by)
          {
              foreach (var pl in Level.Platforms)
                  if (pl.Rect.Contains(bx, by)) return true;
              return false;
          }

          private void HitPlayer()
          {
              Player.Lives--;
              if (Player.Lives <= 0) { Overlay = "GAME OVER"; State = GameState.GameOver; return; }
              Overlay      = $"OUCH!  Lives left: {Player.Lives}";
              _stateTimer  = 100;
              State        = GameState.PlayerHit;
              SpawnParticles(Player.X + Player.W/2, Player.Y + Player.H/2,
                             Color.FromArgb(255, 60, 60), 16, 5f);
              Player.IsInvincible  = true;
              Player.InvincibleTimer = 150;
          }

          private void LoadLevel(int n)
          {
              Level = LevelBuilder.Build(n);
              Enemies.Clear(); Coins.Clear(); Bullets.Clear();
              foreach (var ed in Level.EnemyDefs)
                  Enemies.Add(new Enemy(ed.X, ed.Y, ed.Kind, ed.Min, ed.Max, ed.Horiz));
              foreach (var cd in Level.CoinDefs)
                  Coins.Add(new Coin(cd.X, cd.Y));
          }

          private void SpawnParticles(float x, float y, Color col, int n, float spd)
          {
              for (int i = 0; i < n; i++)
              {
                  float a  = (float)(_rnd.NextDouble() * Math.PI * 2);
                  float s  = (float)(_rnd.NextDouble() * spd + 0.5f);
                  float sz = (float)(_rnd.NextDouble() * 4 + 2);
                  Particles.Add(new Particle(x, y,
                      (float)Math.Cos(a)*s, (float)Math.Sin(a)*s,
                      20 + _rnd.Next(20), col, sz));
              }
          }

          private void SpawnEnemyDeath(Enemy e)
          {
              Color col = e.Kind == EnemyKind.Bug   ? Color.FromArgb(255, 80, 30) :
                          e.Kind == EnemyKind.Virus  ? Color.FromArgb(220, 0, 80)  :
                                                       Color.FromArgb(80, 160, 255);
              SpawnParticles(e.X + e.W/2, e.Y + e.H/2, col, 20, 5f);
          }
      }
  }