namespace EscapeFromBuffer
  {
      internal enum GameState
      {
          Menu,
          Instructions,
          LevelSelect,
          Playing,
          PlayerHit,
          LevelComplete,
          GameOver,
          Victory
      }
  }