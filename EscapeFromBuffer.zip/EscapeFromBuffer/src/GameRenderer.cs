using System;
  using System.Drawing;
  using System.Drawing.Drawing2D;
  using System.Drawing.Text;
  using System.Windows.Forms;

  namespace EscapeFromBuffer
  {
      // ── scrolling background rain drop ───────────────────────────────
      internal struct RainDrop
      {
          public float X, Y, Speed;
          public int   GlyphIdx;
          public int   Brightness;
      }

      internal sealed class GameRenderer : IDisposable
      {
          // ── Panel / view constants ────────────────────────────────────
          public const int PanelW  = 900;
          public const int PanelH  = 540;
          public const int HudH    = 44;
          public const int ViewH   = PanelH - HudH;   // 496
          public const int CamW    = PanelW;

          // ── Fonts ─────────────────────────────────────────────────────
          private readonly Font _fHud;       // HUD labels
          private readonly Font _fBig;       // overlay / title
          private readonly Font _fMed;       // menu items
          private readonly Font _fSmall;     // hints
          private readonly Font _fTitle;     // giant title

          // ── Brushes + pens (persistent) ───────────────────────────────
          private readonly SolidBrush _bkBlack;
          private readonly SolidBrush _bkHud;
          private readonly Pen        _pHud;
          private readonly Pen        _pGlow;

          // ── Camera ────────────────────────────────────────────────────
          private float _camX;
          private float _camY;

          // ── Background rain ───────────────────────────────────────────
          private readonly RainDrop[] _rain;
          private readonly Random     _rnd = new Random(42);
          private static readonly char[] _glyphs = "01アイウエオカキクケコサシスセソタチツテトナニヌネノ".ToCharArray();

          public GameRenderer()
          {
              _fHud   = new Font("Consolas",  11f, FontStyle.Bold,    GraphicsUnit.Point);
              _fBig   = new Font("Consolas",  22f, FontStyle.Bold,    GraphicsUnit.Point);
              _fMed   = new Font("Consolas",  15f, FontStyle.Bold,    GraphicsUnit.Point);
              _fSmall = new Font("Consolas",   9f, FontStyle.Regular, GraphicsUnit.Point);
              _fTitle = new Font("Consolas",  36f, FontStyle.Bold,    GraphicsUnit.Point);

              _bkBlack = new SolidBrush(Color.Black);
              _bkHud   = new SolidBrush(Color.FromArgb(220, 10, 14, 10));
              _pHud    = new Pen(Color.FromArgb(0, 180, 60), 1.5f);
              _pGlow   = new Pen(Color.FromArgb(80, 0, 255, 120), 3f);

              // initialise rain
              _rain = new RainDrop[120];
              for (int i = 0; i < _rain.Length; i++) InitRain(i, true);
          }

          private void InitRain(int i, bool randomY)
          {
              _rain[i].X          = _rnd.Next(PanelW);
              _rain[i].Y          = randomY ? _rnd.Next(PanelH) : -_rnd.Next(60);
              _rain[i].Speed      = 1.5f + (float)(_rnd.NextDouble() * 3.5f);
              _rain[i].GlyphIdx   = _rnd.Next(_glyphs.Length);
              _rain[i].Brightness = 80 + _rnd.Next(160);
          }

          // ── Main entry ────────────────────────────────────────────────
          public void Draw(Graphics g, GameEngine eng, int panelW, int panelH,
                           int sel, bool flash, int tick)
          {
              g.TextRenderingHint = TextRenderingHint.ClearTypeGridFit;
              g.SmoothingMode     = SmoothingMode.AntiAlias;

              switch (eng.State)
              {
                  case GameState.Menu:          DrawMenu(g, panelW, panelH, sel, tick); break;
                  case GameState.Instructions:  DrawInstructions(g, panelW, panelH);    break;
                  case GameState.LevelSelect:   DrawLevelSelect(g, panelW, panelH, sel, tick); break;
                  case GameState.Playing:
                  case GameState.PlayerHit:     DrawGame(g, eng, panelW, panelH, flash, tick); break;
                  case GameState.LevelComplete: DrawLevelComplete(g, eng, panelW, panelH, tick); break;
                  case GameState.GameOver:      DrawGameOver(g, panelW, panelH, eng.Player.Score, tick); break;
                  case GameState.Victory:       DrawVictory(g, panelW, panelH, eng.Player.Score, tick); break;
              }
          }

          // ─────────────────────────────────────────────────────────────
          //  BACKGROUND helpers
          // ─────────────────────────────────────────────────────────────
          private void DrawBackground(Graphics g, LevelData lvl, int panelW, int panelH,
                                      float camX, int tick)
          {
              // Sky gradient
              using (var br = new LinearGradientBrush(
                  new Point(0, 0), new Point(0, panelH), lvl.SkyTop, lvl.SkyBot))
                  g.FillRectangle(br, 0, 0, panelW, panelH);

              // Scrolling rain (Matrix-style) using level accent colour
              UpdateRain(tick);
              DrawRain(g, lvl, panelW, panelH, camX);

              // Distant grid lines (parallax at 30%)
              DrawGrid(g, lvl, panelW, panelH, camX * 0.3f);
          }

          private void UpdateRain(int tick)
          {
              if (tick % 2 != 0) return;
              for (int i = 0; i < _rain.Length; i++)
              {
                  _rain[i].Y += _rain[i].Speed;
                  if (_rain[i].Y > PanelH + 20) InitRain(i, false);
                  if (tick % 8 == 0) _rain[i].GlyphIdx = _rnd.Next(_glyphs.Length);
              }
          }

          private void DrawRain(Graphics g, LevelData lvl, int panelW, int panelH, float camX)
          {
              Color acc = lvl.PlatformAccent;
              using (var font = new Font("Consolas", 9f, FontStyle.Regular, GraphicsUnit.Point))
              {
                  foreach (var r in _rain)
                  {
                      int a = (int)(r.Brightness * 0.45f);
                      using (var br = new SolidBrush(Color.FromArgb(a, acc)))
                          g.DrawString(_glyphs[r.GlyphIdx].ToString(), font, br, r.X, r.Y);
                  }
              }
          }

          private void DrawGrid(Graphics g, LevelData lvl, int panelW, int panelH, float offX)
          {
              Color acc = lvl.PlatformAccent;
              using (var p = new Pen(Color.FromArgb(18, acc), 1))
              {
                  int gx = (int)(offX % 80);
                  for (int x = -gx; x < panelW; x += 80)
                      g.DrawLine(p, x, HudH, x, panelH);
                  for (int y = HudH; y < panelH; y += 60)
                      g.DrawLine(p, 0, y, panelW, y);
              }
          }

          // ─────────────────────────────────────────────────────────────
          //  PLATFORM drawing
          // ─────────────────────────────────────────────────────────────
          private void DrawPlatforms(Graphics g, LevelData lvl, float camX, int panelW, int tick)
          {
              foreach (var pf in lvl.Platforms)
              {
                  float sx = pf.X - camX;
                  float sy = pf.Y - _camY + HudH;
                  if (sx + pf.W < 0 || sx > panelW) continue;

                  var r = new RectangleF(sx, sy, pf.W, pf.H);
                  DrawSinglePlatform(g, r, pf.Style, lvl.PlatformAccent, tick);
              }
          }

          private void DrawSinglePlatform(Graphics g, RectangleF r,
                                           PlatformStyle style, Color accent, int tick)
          {
              // Colours based on style
              Color dark, mid, top, trace;
              switch (style)
              {
                  case PlatformStyle.Glowing:
                      dark  = Color.FromArgb(20, 40, 20);
                      mid   = Color.FromArgb(30, 70, 35);
                      top   = accent;
                      trace = Color.FromArgb(120, accent);
                      break;
                  case PlatformStyle.Ice:
                      dark  = Color.FromArgb(10, 20, 50);
                      mid   = Color.FromArgb(20, 50, 100);
                      top   = Color.FromArgb(140, 200, 255);
                      trace = Color.FromArgb(80, 140, 200, 255);
                      break;
                  case PlatformStyle.Lava:
                      dark  = Color.FromArgb(50, 10, 0);
                      mid   = Color.FromArgb(110, 30, 0);
                      top   = Color.FromArgb(255, 80, 0);
                      trace = Color.FromArgb(120, 255, 80, 0);
                      break;
                  case PlatformStyle.Circuit:
                      dark  = Color.FromArgb(12, 22, 12);
                      mid   = Color.FromArgb(22, 40, 22);
                      top   = Color.FromArgb(0, 160, 60);
                      trace = Color.FromArgb(60, 0, 160, 60);
                      break;
                  default: // Metal
                      dark  = Color.FromArgb(30, 35, 30);
                      mid   = Color.FromArgb(55, 65, 55);
                      top   = Color.FromArgb(100, 130, 100);
                      trace = Color.FromArgb(50, 80, 120, 80);
                      break;
              }

              // Body gradient
              using (var br = new LinearGradientBrush(
                  new PointF(r.Left, r.Top), new PointF(r.Left, r.Bottom), mid, dark))
                  g.FillRectangle(br, r);

              // Circuit traces (horizontal lines)
              using (var tp = new Pen(trace, 1))
              {
                  float spacing = 6f;
                  for (float ty = r.Top + spacing; ty < r.Bottom; ty += spacing)
                      g.DrawLine(tp, r.Left + 4, ty, r.Right - 4, ty);

                  // Vertical nubs
                  int nubs = (int)(r.Width / 24);
                  for (int i = 0; i <= nubs; i++)
                  {
                      float nx = r.Left + i * (r.Width / (nubs + 1));
                      g.DrawLine(tp, nx, r.Top, nx, r.Top + 6);
                  }
              }

              // Top highlight edge
              int pulse = (int)(4 + 2 * Math.Sin(tick * 0.05 + r.X * 0.01));
              using (var tp = new Pen(top, 3))
                  g.DrawLine(tp, r.Left, r.Top, r.Right, r.Top);

              // Glow on top (Glowing / Ice / Lava)
              if (style == PlatformStyle.Glowing || style == PlatformStyle.Ice || style == PlatformStyle.Lava)
              {
                  int ga = (int)(30 + 20 * Math.Sin(tick * 0.05));
                  using (var gb = new SolidBrush(Color.FromArgb(ga, top)))
                  using (var gpath = new GraphicsPath())
                  {
                      gpath.AddRectangle(new RectangleF(r.Left, r.Top - 6, r.Width, 8));
                      g.FillPath(gb, gpath);
                  }
              }

              // Side corners
              using (var sp = new Pen(Color.FromArgb(80, top), 1))
              {
                  g.DrawLine(sp, r.Left,  r.Top, r.Left,  r.Bottom);
                  g.DrawLine(sp, r.Right, r.Top, r.Right, r.Bottom);
              }
          }
  
          // ─────────────────────────────────────────────────────────────
          //  PLAYER sprite (GDI+ drawn, no images)
          // ─────────────────────────────────────────────────────────────
          private void DrawPlayer(Graphics g, Player p, float camX, bool flash, int tick)
          {
              if (!flash) return;   // invincibility blink
              float sx = p.X - camX;
              float sy = p.Y - _camY + HudH;
              bool  fr = p.FacingRight;

              g.SmoothingMode = SmoothingMode.AntiAlias;

              // ── Legs (two blocks, animated walk) ─────────────────────
              Color legCol  = Color.FromArgb(30, 80, 160);
              Color bootCol = Color.FromArgb(20, 50, 100);
              float legW = 10f, legH = 14f;
              float legOff = (p.OnGround && Math.Abs(p.VX) > 0.3f)
                             ? (float)Math.Sin(tick * 0.3f) * 4f : 0f;
              // left leg
              FillRoundRect(g, sx + 4,         sy + p.H - legH + legOff,  legW, legH, 3, legCol);
              FillRect(g,      sx + 3,         sy + p.H - 5 + legOff,     legW+2, 5, bootCol);
              // right leg
              FillRoundRect(g, sx + p.W - 14,  sy + p.H - legH - legOff,  legW, legH, 3, legCol);
              FillRect(g,      sx + p.W - 15,  sy + p.H - 5 - legOff,     legW+2, 5, bootCol);

              // ── Body / torso ──────────────────────────────────────────
              Color bodyTop = Color.FromArgb(40, 120, 220);
              Color bodyBot = Color.FromArgb(20, 60, 140);
              float bx = sx + 3, by = sy + 16, bw = p.W - 6, bh = p.H - 32;
              using (var br = new LinearGradientBrush(
                  new PointF(bx, by), new PointF(bx, by + bh), bodyTop, bodyBot))
                  FillRoundRectBrush(g, bx, by, bw, bh, 5, br);

              // armour stripe
              using (var sp = new Pen(Color.FromArgb(80, 160, 255), 1.5f))
              {
                  g.DrawLine(sp, bx + 4, by + 4, bx + bw - 4, by + 4);
                  g.DrawLine(sp, bx + 4, by + 8, bx + bw - 4, by + 8);
              }

              // ── Gun arm ───────────────────────────────────────────────
              float gunX = fr ? sx + p.W - 6 : sx - 8;
              float gunY = sy + 22;
              FillRoundRect(g, gunX, gunY, 16, 8, 3, Color.FromArgb(60, 160, 255));
              // muzzle flash when shooting
              if (p.ShootCooldown > 10)
              {
                  float mx = fr ? gunX + 16 : gunX - 6;
                  using (var mf = new SolidBrush(Color.FromArgb(200, 255, 240, 80)))
                      g.FillEllipse(mf, mx - 5, gunY - 3, 10, 14);
              }

              // ── Head ─────────────────────────────────────────────────
              float hx = sx + 4, hy = sy + 1, hw = p.W - 8, hh = 18;
              Color headCol = Color.FromArgb(50, 140, 240);
              FillRoundRect(g, hx, hy, hw, hh, 5, headCol);

              // visor (dark glass)
              float vx = hx + (fr ? 6 : 2), vy = hy + 4, vw = hw - 8, vh = 8;
              using (var vbr = new LinearGradientBrush(
                  new PointF(vx, vy), new PointF(vx, vy+vh),
                  Color.FromArgb(180, 0, 200, 255), Color.FromArgb(80, 0, 80, 150)))
                  g.FillRectangle(vbr, vx, vy, vw, vh);

              // visor shine
              using (var sp = new SolidBrush(Color.FromArgb(100, 255, 255, 255)))
                  g.FillRectangle(sp, vx + 1, vy + 1, vw * 0.4f, 2);

              // antenna
              using (var ap = new Pen(Color.FromArgb(0, 220, 80), 1.5f))
              {
                  g.DrawLine(ap, hx + hw/2, hy, hx + hw/2 + (fr?2:-2), hy - 6);
                  g.FillEllipse(new SolidBrush(Color.FromArgb(0, 255, 120)),
                                hx + hw/2 - 3 + (fr?2:-2), hy - 9, 6, 6);
              }

              // ── Glow aura (full health) ───────────────────────────────
              using (var gp = new Pen(Color.FromArgb(25, 0, 180, 255), 6))
                  g.DrawRectangle(gp, sx + 1, sy + 1, p.W - 2, p.H - 2);
          }

          // ─────────────────────────────────────────────────────────────
          //  ENEMY sprites
          // ─────────────────────────────────────────────────────────────
          private void DrawEnemies(Graphics g, System.Collections.Generic.List<Enemy> enemies,
                                    float camX, int tick)
          {
              foreach (var e in enemies)
              {
                  if (!e.Active) continue;
                  float sx = e.X - camX;
                  float sy = e.Y - _camY + HudH;
                  if (sx + e.W < -10 || sx > CamW + 10) continue;

                  bool hitFlash = e.HitFlash > 0 && (e.HitFlash % 2 == 0);

                  switch (e.Kind)
                  {
                      case EnemyKind.Bug:   DrawBug(g, sx, sy, e, tick, hitFlash);   break;
                      case EnemyKind.Virus: DrawVirus(g, sx, sy, e, tick, hitFlash); break;
                      case EnemyKind.Drone: DrawDrone(g, sx, sy, e, tick, hitFlash); break;
                  }

                  DrawHealthBar(g, sx, sy - 8, e.W, e.Health, e.MaxHealth);
              }
          }

          private void DrawBug(Graphics g, float sx, float sy, Enemy e, int tick, bool flash)
          {
              Color body  = flash ? Color.White : Color.FromArgb(200, 40, 20);
              Color eye   = Color.FromArgb(255, 220, 0);
              Color leg   = Color.FromArgb(160, 30, 10);
              float cx = sx + e.W/2, cy = sy + e.H/2;

              // legs (3 per side, animated)
              float legAnim = (float)Math.Sin(tick * 0.25f) * 5f;
              using (var lp = new Pen(leg, 2))
              {
                  for (int i = 0; i < 3; i++)
                  {
                      float fy = sy + 10 + i * 10;
                      float la = (i % 2 == 0) ? legAnim : -legAnim;
                      g.DrawLine(lp, cx - 8, fy, sx,           fy + la);
                      g.DrawLine(lp, cx + 8, fy, sx + e.W,     fy - la);
                  }
              }

              // body shell
              using (var br = new SolidBrush(body))
                  g.FillEllipse(br, sx + 4, sy + 6, e.W - 8, e.H - 10);
              // shell highlight
              using (var br = new SolidBrush(Color.FromArgb(80, 255, 160, 140)))
                  g.FillEllipse(br, sx + 8, sy + 8, (e.W - 8) * 0.5f, 6);
              // shell segments
              using (var sp = new Pen(Color.FromArgb(120, 100, 0, 0), 1))
              {
                  g.DrawEllipse(sp, sx + 4, sy + 6,  e.W - 8, e.H - 10);
                  g.DrawLine(sp, cx, sy + 6, cx, sy + e.H - 4);
              }

              // head + eyes
              FillRoundRect(g, sx + 6, sy, e.W - 12, 12, 4, Color.FromArgb(180, 30, 10));
              // eyes (X pattern)
              DrawXEye(g, cx - 8, sy + 4, eye);
              DrawXEye(g, cx + 4, sy + 4, eye);

              // antennae
              using (var ap = new Pen(leg, 1.5f))
              {
                  g.DrawLine(ap, cx - 6, sy, cx - 10, sy - 8);
                  g.DrawLine(ap, cx + 6, sy, cx + 10, sy - 8);
              }
          }

          private void DrawXEye(Graphics g, float ex, float ey, Color col)
          {
              using (var p = new Pen(col, 1.5f))
              {
                  g.DrawLine(p, ex,     ey,     ex + 5, ey + 5);
                  g.DrawLine(p, ex + 5, ey,     ex,     ey + 5);
              }
          }

          private void DrawVirus(Graphics g, float sx, float sy, Enemy e, int tick, bool flash)
          {
              Color core  = flash ? Color.White : Color.FromArgb(200, 0, 80);
              Color spike = Color.FromArgb(220, 0, 60);
              float cx = sx + e.W/2, cy = sy + e.H/2;
              float r  = e.W / 2f - 4;

              // outer glow
              int ga = (int)(30 + 20 * Math.Sin(tick * 0.08f));
              using (var gb = new SolidBrush(Color.FromArgb(ga, 255, 0, 80)))
                  g.FillEllipse(gb, cx - r - 6, cy - r - 6, (r + 6)*2, (r + 6)*2);

              // spikes (8 directions)
              float pulse = 1f + 0.1f * (float)Math.Sin(tick * 0.1f);
              using (var sp = new Pen(spike, 2.5f))
              {
                  for (int i = 0; i < 8; i++)
                  {
                      double a = i * Math.PI / 4 + tick * 0.02;
                      float x1 = cx + (float)Math.Cos(a) * (r - 2);
                      float y1 = cy + (float)Math.Sin(a) * (r - 2);
                      float x2 = cx + (float)Math.Cos(a) * (r + 8 * pulse);
                      float y2 = cy + (float)Math.Sin(a) * (r + 8 * pulse);
                      g.DrawLine(sp, x1, y1, x2, y2);
                  }
              }

              // core body
              using (var br = new SolidBrush(core))
                  g.FillEllipse(br, cx - r, cy - r, r*2, r*2);
              // inner highlight
              using (var br = new SolidBrush(Color.FromArgb(80, 255, 180, 200)))
                  g.FillEllipse(br, cx - r*0.5f, cy - r*0.7f, r*0.6f, r*0.4f);

              // angry eyes
              using (var ep = new Pen(Color.FromArgb(255, 220, 0), 2))
              {
                  g.DrawLine(ep, cx - 8, cy - 5, cx - 3, cy - 2);
                  g.DrawLine(ep, cx + 8, cy - 5, cx + 3, cy - 2);
              }
              using (var br = new SolidBrush(Color.FromArgb(255, 220, 0)))
              {
                  g.FillEllipse(br, cx - 8, cy - 2, 6, 6);
                  g.FillEllipse(br, cx + 2, cy - 2, 6, 6);
              }
          }

          private void DrawDrone(Graphics g, float sx, float sy, Enemy e, int tick, bool flash)
          {
              Color hull   = flash ? Color.White : Color.FromArgb(60, 120, 200);
              Color accent = Color.FromArgb(0, 200, 255);
              float cx = sx + e.W/2, cy = sy + e.H/2;
              float hover  = (float)Math.Sin(tick * 0.08f) * 3f;

              // rotor blades (spinning)
              float bladeAngle = tick * 8f;
              using (var bp = new Pen(Color.FromArgb(120, 200, 255), 2))
              {
                  for (int i = 0; i < 2; i++)
                  {
                      double a = bladeAngle * Math.PI / 180 + i * Math.PI;
                      float x1 = cx + (float)Math.Cos(a) * 18;
                      float y1 = sy + hover + 2 + (float)Math.Sin(a) * 4;
                      float x2 = cx - (float)Math.Cos(a) * 18;
                      float y2 = sy + hover + 2 - (float)Math.Sin(a) * 4;
                      g.DrawLine(bp, x1, y1, x2, y2);
                  }
              }

              // chassis body
              float bx = sx + 4, by = sy + 10 + hover, bw = e.W - 8, bh = e.H - 16;
              using (var br = new LinearGradientBrush(
                  new PointF(bx, by), new PointF(bx, by + bh), hull, Color.FromArgb(30, 60, 120)))
                  FillRoundRectBrush(g, bx, by, bw, bh, 6, br);

              // border
              using (var sp = new Pen(accent, 1.5f))
                  g.DrawRectangle(sp, bx, by, bw, bh);

              // panel lines
              using (var lp = new Pen(Color.FromArgb(40, accent), 1))
              {
                  g.DrawLine(lp, bx + 6, by + 4, bx + bw - 6, by + 4);
                  g.DrawLine(lp, bx + 6, by + 8, bx + bw - 6, by + 8);
              }

              // targeting eye
              int ea = (int)(200 + 55 * Math.Sin(tick * 0.12f));
              using (var eb = new SolidBrush(Color.FromArgb(ea, 255, 40, 40)))
                  g.FillEllipse(eb, cx - 6, by + bh/2 - 5, 12, 10);
              using (var ep = new Pen(Color.FromArgb(255, 40, 40), 1.5f))
                  g.DrawEllipse(ep, cx - 6, by + bh/2 - 5, 12, 10);

              // signal lines
              if (e.ShootTimer % 30 < 15)
              {
                  using (var sp2 = new Pen(Color.FromArgb(60, 255, 40, 40), 1))
                  {
                      g.DrawLine(sp2, cx - 14, by + bh/2, cx - 7, by + bh/2);
                      g.DrawLine(sp2, cx + 7,  by + bh/2, cx + 14, by + bh/2);
                  }
              }

              // under-glow
              using (var ug = new SolidBrush(Color.FromArgb(20, accent)))
                  g.FillEllipse(ug, bx - 4, by + bh - 2, bw + 8, 10);
          }

          // ─────────────────────────────────────────────────────────────
          //  BULLET drawing
          // ─────────────────────────────────────────────────────────────
          private void DrawBullets(Graphics g,
                                     System.Collections.Generic.List<Bullet> bullets,
                                     float camX)
          {
              foreach (var b in bullets)
              {
                  if (!b.Active) continue;
                  float sx = b.X - camX;
                  float sy = b.Y - _camY + HudH;

                  if (b.FromPlayer)
                  {
                      // Cyan laser bolt
                      using (var glow = new SolidBrush(Color.FromArgb(40, 0, 220, 255)))
                          g.FillEllipse(glow, sx - 4, sy - 4, Bullet.W + 8, Bullet.H + 8);
                      using (var core = new SolidBrush(Color.FromArgb(0, 240, 255)))
                          g.FillRectangle(core, sx, sy, Bullet.W, Bullet.H);
                      using (var bright = new SolidBrush(Color.White))
                          g.FillRectangle(bright, sx + 2, sy + 1, Bullet.W - 6, Bullet.H - 2);
                  }
                  else
                  {
                      // Red enemy shot — spinning orb
                      using (var glow = new SolidBrush(Color.FromArgb(50, 255, 0, 0)))
                          g.FillEllipse(glow, sx - 5, sy - 5, 20, 20);
                      using (var core = new SolidBrush(Color.FromArgb(255, 80, 30)))
                          g.FillEllipse(core, sx, sy, 10, 10);
                      using (var bright = new SolidBrush(Color.FromArgb(200, 255, 200, 180)))
                          g.FillEllipse(bright, sx + 2, sy + 2, 4, 4);
                  }
              }
          }

          // ─────────────────────────────────────────────────────────────
          //  COIN drawing
          // ─────────────────────────────────────────────────────────────
          private void DrawCoins(Graphics g,
                                   System.Collections.Generic.List<Coin> coins,
                                   float camX, int tick)
          {
              foreach (var c in coins)
              {
                  if (c.Collected) continue;
                  float sx = c.X - camX;
                  float sy = c.Y - _camY + HudH;
                  if (sx < -30 || sx > CamW + 30) continue;

                  // Outer glow
                  int ga = (int)(30 + 20 * Math.Sin(tick * 0.1f));
                  using (var gb = new SolidBrush(Color.FromArgb(ga, 255, 215, 0)))
                      g.FillEllipse(gb, sx - Coin.R - 6, sy - Coin.R - 6, (Coin.R+6)*2, (Coin.R+6)*2);

                  // Coin body (squish for spin illusion)
                  float squish = (float)Math.Abs(Math.Cos(c.Angle * Math.PI / 180));
                  float cw = Coin.R * 2 * (0.3f + 0.7f * squish);
                  float cx = sx - cw / 2, cy = sy - Coin.R;

                  using (var br = new LinearGradientBrush(
                      new PointF(cx, cy), new PointF(cx + cw, cy),
                      Color.FromArgb(255, 230, 40), Color.FromArgb(200, 150, 0)))
                      g.FillEllipse(br, cx, cy, cw, Coin.R * 2);

                  // Shine
                  using (var sh = new SolidBrush(Color.FromArgb(120, 255, 255, 200)))
                      g.FillEllipse(sh, cx + cw * 0.1f, cy + 2, cw * 0.35f, Coin.R * 0.6f);

                  // Symbol
                  using (var sf = new Font("Consolas", 9f, FontStyle.Bold, GraphicsUnit.Point))
                  using (var sb = new SolidBrush(Color.FromArgb(140, 100, 0)))
                  {
                      if (squish > 0.5f)
                          g.DrawString("$", sf, sb, sx - 5, sy - 8);
                  }
              }
          }

          // ─────────────────────────────────────────────────────────────
          //  EXIT PORTAL drawing
          // ─────────────────────────────────────────────────────────────
          private void DrawPortal(Graphics g, RectangleF portal, float camX, int tick)
          {
              float sx = portal.X - camX;
              float sy = portal.Y - _camY + HudH;
              float pw = portal.Width, ph = portal.Height;
              float cx = sx + pw/2, cy = sy + ph/2;

              // Outer spinning rings
              for (int ring = 3; ring >= 0; ring--)
              {
                  float rr    = pw/2 + ring * 8 + 3;
                  float angle = tick * (3 + ring) * (ring % 2 == 0 ? 1 : -1);
                  int alpha   = 30 + ring * 12;
                  using (var rp = new Pen(Color.FromArgb(alpha, 0, 230, 130), 3 - ring * 0.5f))
                  {
                      g.DrawArc(rp, cx - rr, cy - rr, rr*2, rr*2,
                                angle, 300 - ring * 20);
                  }
              }

              // Portal fill — swirling gradient
              int pa = (int)(80 + 40 * Math.Sin(tick * 0.08f));
              using (var pgb = new PathGradientBrush(new PointF[] {
                  new PointF(cx - pw/2, cy - ph/2),
                  new PointF(cx + pw/2, cy - ph/2),
                  new PointF(cx + pw/2, cy + ph/2),
                  new PointF(cx - pw/2, cy + ph/2) }))
              {
                  pgb.CenterColor = Color.FromArgb(pa + 60, 0, 255, 180);
                  pgb.SurroundColors = new[] { Color.FromArgb(pa, 0, 80, 40) };
                  g.FillEllipse(pgb, sx, sy, pw, ph);
              }

              // Scanlines inside portal
              using (var slp = new Pen(Color.FromArgb(30, 0, 255, 150), 1))
              {
                  for (float ly = sy + 4; ly < sy + ph - 4; ly += 6)
                      g.DrawLine(slp, sx + 4, ly, sx + pw - 4, ly);
              }

              // "EXIT" label
              using (var f  = new Font("Consolas", 9f, FontStyle.Bold, GraphicsUnit.Point))
              using (var fb = new SolidBrush(Color.FromArgb(220, 0, 255, 150)))
              {
                  var sz = g.MeasureString("EXIT", f);
                  g.DrawString("EXIT", f, fb, cx - sz.Width/2, cy - sz.Height/2);
              }

              // Frame
              using (var fp = new Pen(Color.FromArgb(200, 0, 230, 100), 2))
                  g.DrawRectangle(fp, sx, sy, pw, ph);
          }

          // ─────────────────────────────────────────────────────────────
          //  PARTICLES
          // ─────────────────────────────────────────────────────────────
          private void DrawParticles(Graphics g,
                                      System.Collections.Generic.List<Particle> parts,
                                      float camX)
          {
              foreach (var p in parts)
              {
                  if (!p.Alive) continue;
                  float sx = p.X - camX;
                  float sy = p.Y - _camY + HudH;
                  int a  = (int)(p.Alpha * 220);
                  if (a <= 0) continue;
                  using (var br = new SolidBrush(Color.FromArgb(a, p.Col)))
                      g.FillEllipse(br, sx - p.Size/2, sy - p.Size/2, p.Size, p.Size);
              }
          }

          // ─────────────────────────────────────────────────────────────
          //  HEALTH BAR above enemy
          // ─────────────────────────────────────────────────────────────
          private void DrawHealthBar(Graphics g, float sx, float sy, float w, int hp, int max)
          {
              float bw = w * 0.9f, bh = 4f;
              float bx = sx + w * 0.05f;
              g.FillRectangle(Brushes.DimGray, bx, sy, bw, bh);
              float filled = bw * hp / max;
              Color hc = hp > max / 2 ? Color.FromArgb(60, 220, 60) :
                         hp > max / 4 ? Color.FromArgb(255, 180, 0) :
                                        Color.FromArgb(220, 30, 30);
              using (var hb = new SolidBrush(hc))
                  g.FillRectangle(hb, bx, sy, filled, bh);
          }
  
          // ─────────────────────────────────────────────────────────────
          //  HUD (score, level, lives)
          // ─────────────────────────────────────────────────────────────
          private void DrawHud(Graphics g, GameEngine eng, int panelW)
          {
              // Background strip
              using (var br = new LinearGradientBrush(
                  new Point(0, 0), new Point(0, HudH),
                  Color.FromArgb(240, 8, 14, 8), Color.FromArgb(200, 0, 0, 0)))
                  g.FillRectangle(br, 0, 0, panelW, HudH);

              // Bottom border glow
              using (var p = new Pen(Color.FromArgb(150, 0, 200, 60), 1.5f))
                  g.DrawLine(p, 0, HudH - 1, panelW, HudH - 1);

              // Score
              DrawGlowText(g, $"SCORE  {eng.Player.Score:D6}", _fHud,
                           Color.FromArgb(0, 220, 80), 16, 8);

              // Level name
              string lname = $"[ {eng.Level?.Name ?? "ESCAPE FROM BUFFER"} ]";
              var lsz = g.MeasureString(lname, _fHud);
              DrawGlowText(g, lname, _fHud, Color.FromArgb(0, 200, 255),
                           panelW/2 - lsz.Width/2, 8);

              // Lives as hearts
              float lx = panelW - 16;
              for (int i = 0; i < eng.Player.Lives; i++)
              {
                  lx -= 26;
                  DrawHeart(g, lx, 9, 18, Color.FromArgb(255, 60, 100));
              }

              // Invincibility flash indicator
              if (eng.Player.IsInvincible)
              {
                  using (var ib = new SolidBrush(Color.FromArgb(60, 255, 220, 0)))
                      g.FillRectangle(ib, 0, 0, panelW, HudH);
                  DrawGlowText(g, "SHIELD", _fHud, Color.FromArgb(255, 220, 0),
                               panelW - 90, 8);
              }
          }

          private void DrawHeart(Graphics g, float x, float y, float size, Color col)
          {
              using (var path = new GraphicsPath())
              using (var br   = new SolidBrush(col))
              {
                  float s = size / 2f;
                  path.AddBezier(x+s, y+s*1.6f, x-s*0.5f, y+s*0.6f, x-s, y, x, y-s*0.5f);
                  path.AddBezier(x, y-s*0.5f, x+s*0.5f, y-s, x+s*2, y, x+s, y+s*1.6f);
                  g.FillPath(br, path);
              }
          }

          // ─────────────────────────────────────────────────────────────
          //  FULL GAME FRAME
          // ─────────────────────────────────────────────────────────────
          private void DrawGame(Graphics g, GameEngine eng, int w, int h, bool flash, int tick)
          {
              // Camera: smooth follow player
              float targetCam = eng.Player.X - w / 2f + eng.Player.W / 2f;
              targetCam = Math.Max(0, Math.Min(targetCam, eng.Level.WorldW - w));
              _camX += (targetCam - _camX) * 0.12f;
              _camY  = 0;

              DrawBackground(g, eng.Level, w, h, _camX, tick);
              DrawPlatforms(g, eng.Level, _camX, w, tick);
              DrawPortal(g, eng.Level.Portal, _camX, tick);
              DrawCoins(g, eng.Coins, _camX, tick);
              DrawEnemies(g, eng.Enemies, _camX, tick);
              DrawBullets(g, eng.Bullets, _camX);
              DrawPlayer(g, eng.Player, _camX, flash, tick);
              DrawParticles(g, eng.Particles, _camX);
              DrawHud(g, eng, w);

              // Overlay message (player hit)
              if (eng.State == GameState.PlayerHit)
                  DrawOverlayMessage(g, eng.Overlay, w, h);
          }

          private void DrawOverlayMessage(Graphics g, string msg, int w, int h)
          {
              var sz = g.MeasureString(msg, _fBig);
              float ox = (w - sz.Width) / 2f, oy = (h - sz.Height) / 2f;
              using (var back = new SolidBrush(Color.FromArgb(160, 0, 0, 0)))
                  g.FillRectangle(back, ox - 20, oy - 12, sz.Width + 40, sz.Height + 24);
              DrawGlowText(g, msg, _fBig, Color.FromArgb(255, 80, 80), ox, oy);
          }

          // ─────────────────────────────────────────────────────────────
          //  MENU screen
          // ─────────────────────────────────────────────────────────────
          private void DrawMenu(Graphics g, int w, int h, int sel, int tick)
          {
              // Background
              using (var br = new LinearGradientBrush(
                  new Point(0,0), new Point(0,h),
                  Color.FromArgb(0,3,0), Color.FromArgb(0,12,4)))
                  g.FillRectangle(br, 0, 0, w, h);

              // Matrix rain (green accent)
              UpdateRain(tick);
              using (var font = new Font("Consolas", 9f, GraphicsUnit.Point))
              {
                  foreach (var r in _rain)
                  {
                      int a = (int)(r.Brightness * 0.35f);
                      using (var rb = new SolidBrush(Color.FromArgb(a, 0, 200, 60)))
                          g.DrawString(_glyphs[r.GlyphIdx].ToString(), font, rb, r.X, r.Y);
                  }
              }

              // Title "ESCAPE FROM BUFFER" - neon block letters
              float titleY = h * 0.06f;
              DrawNeonTitle(g, "ESCAPE FROM BUFFER", w, titleY, tick);

              // Sub-title
              string sub = "- A CYBERPUNK PLATFORMER -";
              var subSz = g.MeasureString(sub, _fSmall);
              DrawGlowText(g, sub, _fSmall, Color.FromArgb(0, 160, 100),
                           (w - subSz.Width) / 2f, titleY + 120);

              // Menu box
              float boxW = 380, boxH = 240, bx = (w - boxW)/2, by = h * 0.46f;
              DrawMenuBox(g, bx, by, boxW, boxH, tick);

              string[] items = { "▶  Play from Start", "⬡  Choose Level",
                                  "?  Instructions",   "✕  Quit" };
              for (int i = 0; i < items.Length; i++)
              {
                  bool active = i == sel;
                  Color ic = active ? Color.FromArgb(0, 240, 130) : Color.FromArgb(150, 200, 150);
                  float iy = by + 30 + i * 48f;

                  if (active)
                  {
                      using (var hb = new SolidBrush(Color.FromArgb(30, 0, 200, 80)))
                          g.FillRectangle(hb, bx + 8, iy - 4, boxW - 16, 38);
                      using (var hp = new Pen(Color.FromArgb(100, 0, 220, 80), 1))
                          g.DrawRectangle(hp, bx + 8, iy - 4, boxW - 16, 38);
                  }

                  DrawGlowText(g, items[i], _fMed, ic, bx + 32, iy);
              }

              // Hint
              string hint = "Arrow Keys  •  Enter / Number  •  Esc";
              var hsz = g.MeasureString(hint, _fSmall);
              DrawGlowText(g, hint, _fSmall, Color.FromArgb(80, 120, 80),
                           (w - hsz.Width)/2f, h - 28f);
          }

          private void DrawNeonTitle(Graphics g, string text, int w, float y, int tick)
          {
              // Shadow layer
              using (var sb = new SolidBrush(Color.FromArgb(40, 0, 255, 100)))
              {
                  var sz = g.MeasureString(text, _fTitle);
                  g.DrawString(text, _fTitle, sb, (w - sz.Width)/2f + 3, y + 3);
              }

              // Glow (pulsing)
              int ga = (int)(60 + 30 * Math.Sin(tick * 0.06f));
              using (var gb = new SolidBrush(Color.FromArgb(ga, 0, 255, 120)))
              {
                  var sz = g.MeasureString(text, _fTitle);
                  g.DrawString(text, _fTitle, gb, (w - sz.Width)/2f - 1, y - 1);
                  g.DrawString(text, _fTitle, gb, (w - sz.Width)/2f + 1, y + 1);
              }

              // Main text
              using (var mb = new LinearGradientBrush(
                  new PointF(0, y), new PointF(0, y + 80),
                  Color.FromArgb(0, 255, 140), Color.FromArgb(0, 180, 80)))
              {
                  var sz = g.MeasureString(text, _fTitle);
                  g.DrawString(text, _fTitle, mb, (w - sz.Width)/2f, y);
              }

              // Scanline inside title
              var tsz = g.MeasureString(text, _fTitle);
              float tx = (w - tsz.Width)/2f;
              using (var slb = new SolidBrush(Color.FromArgb(18, 255, 255, 255)))
                  for (float ly = y + 4; ly < y + tsz.Height; ly += 6)
                      g.FillRectangle(slb, tx, ly, tsz.Width, 2);
          }

          private void DrawMenuBox(Graphics g, float x, float y, float w, float h, int tick)
          {
              // Dark fill
              using (var br = new SolidBrush(Color.FromArgb(160, 0, 14, 6)))
                  g.FillRectangle(br, x, y, w, h);

              // Animated corner brackets
              float len = 20f;
              float glow = (float)(0.6 + 0.4 * Math.Sin(tick * 0.07));
              using (var cp = new Pen(Color.FromArgb((int)(200*glow), 0, 230, 80), 2.5f))
              {
                  // TL
                  g.DrawLine(cp, x,       y,       x+len, y      ); g.DrawLine(cp, x,       y,       x,      y+len);
                  // TR
                  g.DrawLine(cp, x+w,     y,       x+w-len,y     ); g.DrawLine(cp, x+w,     y,       x+w,    y+len);
                  // BL
                  g.DrawLine(cp, x,       y+h,     x+len, y+h    ); g.DrawLine(cp, x,       y+h,     x,      y+h-len);
                  // BR
                  g.DrawLine(cp, x+w,     y+h,     x+w-len,y+h   ); g.DrawLine(cp, x+w,     y+h,     x+w,    y+h-len);
              }
          }

          // ─────────────────────────────────────────────────────────────
          //  LEVEL SELECT screen
          // ─────────────────────────────────────────────────────────────
          private void DrawLevelSelect(Graphics g, int w, int h, int sel, int tick)
          {
              using (var br = new LinearGradientBrush(
                  new Point(0,0), new Point(0,h),
                  Color.FromArgb(0,3,8), Color.FromArgb(0,6,20)))
                  g.FillRectangle(br, 0, 0, w, h);

              DrawNeonTitle(g, "SELECT  LEVEL", w, 40f, tick);

              string[] lvls = {
                  "LVL 1   THE FIREWALL      [ Intro ]",
                  "LVL 2   THE VIRUS LAB     [ Medium ]",
                  "LVL 3   THE DATA VAULT    [ Hard ]",
                  "LVL 4   THE CORE          [ Boss ]"
              };
              Color[] cols = {
                  Color.FromArgb(0,  220, 80),
                  Color.FromArgb(255, 100, 20),
                  Color.FromArgb(40, 140, 255),
                  Color.FromArgb(255,  30, 30)
              };

              float startY = 160f, step = 70f;
              for (int i = 0; i < 4; i++)
              {
                  bool active = i == sel;
                  float iy = startY + i * step;
                  float bw = w - 120, bx = 60, bh = 52;

                  if (active)
                  {
                      using (var ab = new LinearGradientBrush(
                          new PointF(bx, iy), new PointF(bx+bw, iy),
                          Color.FromArgb(40, cols[i]), Color.FromArgb(5, cols[i])))
                          g.FillRectangle(ab, bx, iy, bw, bh);
                      using (var ap = new Pen(cols[i], 2))
                          g.DrawRectangle(ap, bx, iy, bw, bh);
                  }
                  else
                  {
                      using (var db = new SolidBrush(Color.FromArgb(20, cols[i])))
                          g.FillRectangle(db, bx, iy, bw, bh);
                      using (var dp = new Pen(Color.FromArgb(60, cols[i]), 1))
                          g.DrawRectangle(dp, bx, iy, bw, bh);
                  }

                  string prefix = active ? ">> " : "   ";
                  DrawGlowText(g, prefix + lvls[i], _fMed,
                               active ? cols[i] : Color.FromArgb(140, cols[i]),
                               bx + 20, iy + 14);
              }

              string hint = "BACKSPACE = menu";
              DrawGlowText(g, hint, _fSmall, Color.FromArgb(80,100,80), 30, h - 30f);
          }

          // ─────────────────────────────────────────────────────────────
          //  INSTRUCTIONS screen
          // ─────────────────────────────────────────────────────────────
          private void DrawInstructions(Graphics g, int w, int h)
          {
              using (var br = new LinearGradientBrush(
                  new Point(0,0), new Point(0,h),
                  Color.FromArgb(0,4,12), Color.FromArgb(0,2,6)))
                  g.FillRectangle(br, 0, 0, w, h);

              DrawNeonTitle(g, "COMMAND  MANUAL", w, 30f, 0);

              Color cc = Color.FromArgb(0, 200, 120);
              Color wc = Color.White;
              float sx2 = 80, sy = 140, ls = 30;

              DrawGlowText(g, "[ LEFT / RIGHT ]  Move",           _fMed, wc, sx2, sy);
              DrawGlowText(g, "[ UP ARROW     ]  Jump",           _fMed, wc, sx2, sy+ls*1);
              DrawGlowText(g, "[ SPACE        ]  Fire Laser",     _fMed, wc, sx2, sy+ls*2);
              DrawGlowText(g, "[ ESC          ]  Back to Menu",   _fMed, wc, sx2, sy+ls*3);
              DrawGlowText(g, "[ 1-4          ]  Select from Menu",_fMed,wc, sx2, sy+ls*4);

              DrawGlowText(g, "─────────────────────────────",     _fSmall, cc, sx2, sy+ls*5.5f);
              DrawGlowText(g, "OBJECTIVE",                         _fMed, cc, sx2, sy+ls*6.2f);
              DrawGlowText(g, "  • Collect $ data shards  (+10 pts each)",  _fSmall, wc, sx2, sy+ls*7.2f);
              DrawGlowText(g, "  • Shoot enemies to destroy them (+50 pts)",_fSmall, wc, sx2, sy+ls*8.1f);
              DrawGlowText(g, "  • Reach the EXIT portal to advance",        _fSmall, wc, sx2, sy+ls*9.0f);
              DrawGlowText(g, "  • 3 lives total — don't touch enemies!",    _fSmall, wc, sx2, sy+ls*9.9f);
              DrawGlowText(g, "─────────────────────────────",     _fSmall, cc, sx2, sy+ls*10.8f);
              DrawGlowText(g, "[ BACKSPACE ]  Return to Menu",    _fMed, cc, sx2, sy+ls*11.5f);
          }

          // ─────────────────────────────────────────────────────────────
          //  LEVEL COMPLETE overlay
          // ─────────────────────────────────────────────────────────────
          private void DrawLevelComplete(Graphics g, GameEngine eng, int w, int h, int tick)
          {
              DrawGame(g, eng, w, h, true, tick);

              using (var ov = new SolidBrush(Color.FromArgb(160, 0, 0, 0)))
                  g.FillRectangle(ov, 0, 0, w, h);

              DrawNeonTitle(g, eng.Level?.Name?.ToUpper() ?? "COMPLETE", w, h/2f - 120, tick);

              var sz = g.MeasureString(eng.Overlay, _fBig);
              DrawGlowText(g, eng.Overlay, _fBig, Color.FromArgb(0, 255, 150),
                           (w - sz.Width)/2f, h/2f + 20);

              string cont = "Advancing in  3 …";
              var csz = g.MeasureString(cont, _fSmall);
              DrawGlowText(g, cont, _fSmall, Color.FromArgb(150, 200, 150),
                           (w - csz.Width)/2f, h/2f + 70);
          }

          // ─────────────────────────────────────────────────────────────
          //  GAME OVER screen
          // ─────────────────────────────────────────────────────────────
          private void DrawGameOver(Graphics g, int w, int h, int score, int tick)
          {
              using (var br = new LinearGradientBrush(
                  new Point(0,0), new Point(0,h),
                  Color.FromArgb(18,0,0), Color.FromArgb(4,0,0)))
                  g.FillRectangle(br, 0, 0, w, h);

              // Pulsing red vignette
              int ra = (int)(40 + 20 * Math.Sin(tick * 0.08f));
              using (var vb = new PathGradientBrush(new PointF[]{
                  new PointF(0,0), new PointF(w,0),
                  new PointF(w,h), new PointF(0,h)}))
              {
                  vb.CenterColor   = Color.Transparent;
                  vb.SurroundColors = new[]{ Color.FromArgb(ra, 200, 0, 0) };
                  g.FillRectangle(vb, 0, 0, w, h);
              }

              DrawNeonTitleColor(g, "GAME  OVER", w, h/2f - 120,
                                 Color.FromArgb(255, 30, 30), Color.FromArgb(180, 0, 0), tick);

              string sc = $"Final Score:  {score:D6}";
              var ssz = g.MeasureString(sc, _fBig);
              DrawGlowText(g, sc, _fBig, Color.FromArgb(220, 80, 80),
                           (w - ssz.Width)/2f, h/2f + 30);

              string hint = "ENTER = play again   |   ESC = menu";
              var hsz = g.MeasureString(hint, _fSmall);
              DrawGlowText(g, hint, _fSmall, Color.FromArgb(160, 80, 80),
                           (w - hsz.Width)/2f, h/2f + 90);
          }

          // ─────────────────────────────────────────────────────────────
          //  VICTORY screen
          // ─────────────────────────────────────────────────────────────
          private void DrawVictory(Graphics g, int w, int h, int score, int tick)
          {
              using (var br = new LinearGradientBrush(
                  new Point(0,0), new Point(0,h),
                  Color.FromArgb(0,8,4), Color.FromArgb(0,3,0)))
                  g.FillRectangle(br, 0, 0, w, h);

              // Celebration particles (static stars)
              var rr = new Random(tick / 5);
              for (int i = 0; i < 80; i++)
              {
                  float sx2 = rr.Next(w), sy2 = rr.Next(h);
                  float sr2 = 1f + (float)rr.NextDouble() * 3f;
                  int sa2 = (int)(80 + 120 * Math.Sin(tick * 0.1f + i));
                  using (var sb2 = new SolidBrush(Color.FromArgb(sa2, 0, 255, 120)))
                      g.FillEllipse(sb2, sx2, sy2, sr2, sr2);
              }

              DrawNeonTitle(g, "YOU  ESCAPED!", w, h/2f - 130, tick);

              string sc = $"Total Score:  {score:D6}";
              var ssz = g.MeasureString(sc, _fBig);
              DrawGlowText(g, sc, _fBig, Color.FromArgb(0, 255, 150),
                           (w - ssz.Width)/2f, h/2f + 20);

              string tag = "THE BUFFER IS FREED!";
              var tsz = g.MeasureString(tag, _fMed);
              DrawGlowText(g, tag, _fMed, Color.FromArgb(0, 200, 100),
                           (w - tsz.Width)/2f, h/2f + 68);

              string hint = "ENTER = play again   |   ESC = menu";
              var hsz = g.MeasureString(hint, _fSmall);
              DrawGlowText(g, hint, _fSmall, Color.FromArgb(0, 140, 80),
                           (w - hsz.Width)/2f, h/2f + 110);
          }

          // ─────────────────────────────────────────────────────────────
          //  Drawing helpers
          // ─────────────────────────────────────────────────────────────
          private void DrawGlowText(Graphics g, string text, Font font, Color col,
                                     float x, float y)
          {
              // soft glow
              using (var gb = new SolidBrush(Color.FromArgb(50, col)))
              {
                  g.DrawString(text, font, gb, x - 1, y - 1);
                  g.DrawString(text, font, gb, x + 1, y + 1);
              }
              using (var mb = new SolidBrush(col))
                  g.DrawString(text, font, mb, x, y);
          }

          private void DrawNeonTitleColor(Graphics g, string text, int w, float y,
                                           Color top, Color bot, int tick)
          {
              int ga = (int)(50 + 30 * Math.Sin(tick * 0.06f));
              var sz = g.MeasureString(text, _fTitle);
              float tx = (w - sz.Width) / 2f;

              using (var gb = new SolidBrush(Color.FromArgb(ga, top)))
              {
                  g.DrawString(text, _fTitle, gb, tx - 2, y - 2);
                  g.DrawString(text, _fTitle, gb, tx + 2, y + 2);
              }
              using (var mb = new LinearGradientBrush(
                  new PointF(0, y), new PointF(0, y + 80), top, bot))
                  g.DrawString(text, _fTitle, mb, tx, y);
          }

          private static void FillRect(Graphics g, float x, float y, float w, float h, Color c)
          {
              using (var br = new SolidBrush(c)) g.FillRectangle(br, x, y, w, h);
          }

          private static void FillRoundRect(Graphics g, float x, float y,
                                             float w, float h, float r, Color c)
          {
              using (var br = new SolidBrush(c))
              using (var path = RoundRectPath(x, y, w, h, r))
                  g.FillPath(br, path);
          }

          private static void FillRoundRectBrush(Graphics g, float x, float y,
                                                  float w, float h, float r, Brush br)
          {
              using (var path = RoundRectPath(x, y, w, h, r))
                  g.FillPath(br, path);
          }

          private static GraphicsPath RoundRectPath(float x, float y, float w, float h, float r)
          {
              var p = new GraphicsPath();
              p.AddArc(x, y, r*2, r*2, 180, 90);
              p.AddArc(x+w-r*2, y, r*2, r*2, 270, 90);
              p.AddArc(x+w-r*2, y+h-r*2, r*2, r*2, 0, 90);
              p.AddArc(x, y+h-r*2, r*2, r*2, 90, 90);
              p.CloseFigure();
              return p;
          }

          // ── IDisposable ────────────────────────────────────────────────
          public void Dispose()
          {
              _fHud.Dispose(); _fBig.Dispose(); _fMed.Dispose();
              _fSmall.Dispose(); _fTitle.Dispose();
              _bkBlack.Dispose(); _bkHud.Dispose();
              _pHud.Dispose(); _pGlow.Dispose();
          }
      }
  }