using System.Drawing;

  namespace EscapeFromBuffer
  {
      internal class Player
      {
          // ── Physics ──────────────────────────────────────────────────
          public float X, Y;
          public float VX, VY;
          public bool  OnGround;
          public bool  FacingRight = true;

          // ── Constants ─────────────────────────────────────────────────
          public float W          = 34f;
          public float H          = 48f;
          public float MoveSpeed  = 5f;
          public float JumpForce  = -15f;
          public float GravityVal = 0.65f;
          public float MaxFall    = 14f;

          // ── State ─────────────────────────────────────────────────────
          public int   Lives            = 3;
          public int   Score;
          public bool  IsInvincible;
          public int   InvincibleTimer;
          public int   ShootCooldown;
          public int   AnimTick;
          public int   WalkFrame;

          public bool  IsDead => Lives <= 0;
          public RectangleF Bounds => new RectangleF(X, Y, W, H);

          // ── Spawn helpers ─────────────────────────────────────────────
          public Player(float x, float y) { X = x; Y = y; }

          public void FullReset()
          {
              Lives = 3; Score = 0;
              Respawn(60f, 400f);
          }

          public void Respawn(float sx, float sy)
          {
              X = sx; Y = sy;
              VX = 0; VY = 0;
              OnGround       = false;
              IsInvincible   = true;
              InvincibleTimer = 150;   // 2.5 s at 60 fps
              ShootCooldown  = 0;
          }

          public void Update()
          {
              AnimTick++;
              if (ShootCooldown  > 0) ShootCooldown--;
              if (InvincibleTimer > 0) { InvincibleTimer--; if (InvincibleTimer == 0) IsInvincible = false; }

              // walk-frame changes every 6 ticks while moving
              if (System.Math.Abs(VX) > 0.5f && (AnimTick % 6 == 0))
                  WalkFrame = (WalkFrame + 1) % 4;
          }
      }
  }