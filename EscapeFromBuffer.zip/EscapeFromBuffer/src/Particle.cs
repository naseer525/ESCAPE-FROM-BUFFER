using System.Drawing;

  namespace EscapeFromBuffer
  {
      internal class Particle
      {
          public float  X, Y, VX, VY;
          public int    Life, MaxLife;
          public Color  Col;
          public float  Size;
          public float  Gravity;

          public bool  Alive  => Life > 0;
          public float Alpha  => (float)Life / MaxLife;

          public Particle(float x, float y, float vx, float vy,
                          int life, Color col, float size, float gravity = 0.15f)
          { X=x; Y=y; VX=vx; VY=vy; Life=MaxLife=life; Col=col; Size=size; Gravity=gravity; }

          public void Update()
          {
              if (Life <= 0) return;
              X  += VX; Y  += VY;
              VY += Gravity;
              VX *= 0.97f;
              Life--;
          }
      }
  }