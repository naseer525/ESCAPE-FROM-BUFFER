using System.Drawing;

  namespace EscapeFromBuffer
  {
      internal class Bullet
      {
          public float X, Y, VX, VY;
          public bool  Active;
          public bool  FromPlayer;
          public int   Age;

          public const float W = 18f;
          public const float H = 7f;

          public RectangleF Bounds => new RectangleF(X, Y, W, H);

          public Bullet(float x, float y, float vx, float vy, bool fromPlayer)
          { X=x; Y=y; VX=vx; VY=vy; Active=true; FromPlayer=fromPlayer; }

          public void Update(int worldW)
          {
              if (!Active) return;
              X += VX; Y += VY;
              Age++;
              if (X < -W || X > worldW || Y < -20 || Y > 700) Active = false;
          }
      }
  }