using System.Drawing;

  namespace EscapeFromBuffer
  {
      internal class Coin
      {
          public float X, Y;
          public bool  Collected;
          public float Angle;       // rotation for draw
          public const float R = 11f;

          public Coin(float x, float y) { X=x; Y=y; }

          public RectangleF Bounds => new RectangleF(X - R, Y - R, R*2, R*2);

          public void Update() { Angle += 3f; if (Angle >= 360f) Angle -= 360f; }
      }
  }