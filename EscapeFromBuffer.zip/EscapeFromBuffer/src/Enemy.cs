using System.Drawing;

  namespace EscapeFromBuffer
  {
      internal class Enemy
      {
          public float    X, Y;
          public EnemyKind Kind;
          public float    PatrolMin, PatrolMax;
          public bool     Horiz;
          public int      Dir = 1;
          public int      Health, MaxHealth;
          public bool     Active = true;
          public int      AnimTick;
          public int      ShootTimer;

          public float W, H;
          public RectangleF Bounds => new RectangleF(X, Y, W, H);

          // hit-flash frames
          public int HitFlash;

          public Enemy(float x, float y, EnemyKind kind,
                       float min, float max, bool horiz)
          {
              X=x; Y=y; Kind=kind;
              PatrolMin=min; PatrolMax=max; Horiz=horiz;
              switch(kind)
              {
                  case EnemyKind.Bug:
                      W=42; H=42; Health=MaxHealth=3; break;
                  case EnemyKind.Virus:
                      W=46; H=46; Health=MaxHealth=5; break;
                  case EnemyKind.Drone:
                      W=40; H=36; Health=MaxHealth=7; break;
              }
          }

          public void TakeDamage() { HitFlash=8; if(--Health<=0) Active=false; }

          public void Update()
          {
              AnimTick++;
              if (HitFlash > 0) HitFlash--;
              if (!Active) return;

              float spd = Kind == EnemyKind.Drone ? 1.2f : 1.6f;
              if (Horiz) {
                  X += Dir * spd;
                  if (X <= PatrolMin || X + W >= PatrolMax) Dir *= -1;
              } else {
                  Y += Dir * spd;
                  if (Y <= PatrolMin || Y + H >= PatrolMax) Dir *= -1;
              }
              if (Kind == EnemyKind.Drone) ShootTimer++;
          }
      }
  }