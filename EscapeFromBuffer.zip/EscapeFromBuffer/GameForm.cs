using System;
  using System.Drawing;
  using System.Windows.Forms;

  namespace EscapeFromBuffer
  {
      internal sealed class GameForm : Form
      {
          private readonly GameEngine   _eng;
          private readonly GameRenderer _ren;
          private readonly GamePanel    _panel;
          private readonly Timer        _timer;

          // Input flags
          private bool _kLeft, _kRight;
          private bool _jumpQueued, _fireQueued;

          // Menu state
          private int _sel;
          private int _maxSel = 4;

          // Flash for player hit
          private bool _flash = true;
          private int  _flashTick;

          private int  _tick;

          public GameForm()
          {
              _eng   = new GameEngine();
              _ren   = new GameRenderer();

              _panel = new GamePanel
              {
                  Location  = Point.Empty,
                  Size      = new Size(GameRenderer.PanelW, GameRenderer.PanelH),
                  BackColor = Color.Black
              };
              _panel.Paint += (s, e) =>
                  _ren.Draw(e.Graphics, _eng, _panel.Width, _panel.Height, _sel, _flash, _tick);
              Controls.Add(_panel);

              Text            = "Escape From Buffer";
              BackColor       = Color.Black;
              FormBorderStyle = FormBorderStyle.FixedSingle;
              MaximizeBox     = false;
              StartPosition   = FormStartPosition.CenterScreen;
              KeyPreview      = true;
              ClientSize      = _panel.Size;
              Icon            = SystemIcons.Application;

              _timer          = new Timer { Interval = 16 };  // ~60 fps
              _timer.Tick    += GameLoop;
              _timer.Start();
          }

          private void GameLoop(object sender, EventArgs e)
          {
              _tick++;
              _flashTick++;
              if (_flashTick % 5 == 0) _flash = !_flash;
              if (_eng.State != GameState.PlayerHit) _flash = true;

              bool fire = _fireQueued; _fireQueued = false;
              bool jump = _jumpQueued; _jumpQueued = false;

              _eng.Update(_kLeft, _kRight, jump, fire, false);
              _panel.Invalidate();
          }

          protected override void OnKeyDown(KeyEventArgs e)
          {
              base.OnKeyDown(e);
              e.Handled         = true;
              e.SuppressKeyPress = true;

              switch (_eng.State)
              {
                  case GameState.Playing:
                  case GameState.PlayerHit:
                      HandleGameKey(e.KeyCode);
                      break;

                  case GameState.Menu:
                      HandleMenuKey(e.KeyCode);
                      break;

                  case GameState.LevelSelect:
                      HandleLevelSelectKey(e.KeyCode);
                      break;

                  case GameState.Instructions:
                      if (e.KeyCode == Keys.Back || e.KeyCode == Keys.Escape)
                      { _eng.GoMenu(); _sel = 0; }
                      break;

                  case GameState.GameOver:
                  case GameState.Victory:
                      if (e.KeyCode == Keys.Return)
                      { _eng.StartGame(1); _sel = 0; }
                      else if (e.KeyCode == Keys.Escape)
                      { _eng.GoMenu(); _sel = 0; }
                      break;

                  case GameState.LevelComplete:
                      break; // auto-advances
              }
          }

          protected override void OnKeyUp(KeyEventArgs e)
          {
              base.OnKeyUp(e);
              switch (e.KeyCode)
              {
                  case Keys.Left:  _kLeft  = false; break;
                  case Keys.Right: _kRight = false; break;
                  }
          }

          private void HandleGameKey(Keys k)
          {
              switch (k)
              {
                  case Keys.Left:   _kLeft   = true;  break;
                  case Keys.Right:  _kRight  = true;  break;
                  case Keys.Up:     _jumpQueued = true; break;
                  case Keys.Space:  _fireQueued = true; break;
                  case Keys.Escape:
                      _eng.GoMenu(); _kLeft = _kRight = false; _sel = 0; break;
              }
          }

          private void HandleMenuKey(Keys k)
          {
              switch (k)
              {
                  case Keys.Up:
                      _sel = (_sel - 1 + _maxSel) % _maxSel; break;
                  case Keys.Down:
                      _sel = (_sel + 1) % _maxSel; break;
                  case Keys.Return:
                      ActivateMenu(_sel); break;
                  case Keys.D1: case Keys.NumPad1: ActivateMenu(0); break;
                  case Keys.D2: case Keys.NumPad2: ActivateMenu(1); break;
                  case Keys.D3: case Keys.NumPad3: ActivateMenu(2); break;
                  case Keys.D4: case Keys.NumPad4: ActivateMenu(3); break;
                  case Keys.Escape: Application.Exit(); break;
              }
          }

          private void ActivateMenu(int idx)
          {
              switch (idx)
              {
                  case 0: _eng.StartGame(1);      _sel = 0; break;
                  case 1: _eng.GoLevelSelect();   _sel = 0; break;
                  case 2: _eng.GoInstructions();  _sel = 0; break;
                  case 3: Application.Exit();           break;
              }
          }

          private void HandleLevelSelectKey(Keys k)
          {
              switch (k)
              {
                  case Keys.Up:   _sel = (_sel - 1 + 4) % 4; break;
                  case Keys.Down: _sel = (_sel + 1) % 4;     break;
                  case Keys.Return:
                      _eng.StartGame(_sel + 1); _sel = 0; break;
                  case Keys.D1: case Keys.NumPad1: _eng.StartGame(1); _sel = 0; break;
                  case Keys.D2: case Keys.NumPad2: _eng.StartGame(2); _sel = 0; break;
                  case Keys.D3: case Keys.NumPad3: _eng.StartGame(3); _sel = 0; break;
                  case Keys.D4: case Keys.NumPad4: _eng.StartGame(4); _sel = 0; break;
                  case Keys.Back:
                  case Keys.Escape: _eng.GoMenu(); _sel = 0; break;
              }
          }

          protected override void OnFormClosed(FormClosedEventArgs e)
          {
              _timer.Stop();
              _ren.Dispose();
              base.OnFormClosed(e);
          }

          protected override bool IsInputKey(Keys k)
          {
              switch (k & Keys.KeyCode)
              {
                  case Keys.Left: case Keys.Right:
                  case Keys.Up:   case Keys.Down:
                      return true;
                  default: return base.IsInputKey(k);
              }
          }
      }

      internal sealed class GamePanel : Panel
      {
          public GamePanel()
          {
              SetStyle(ControlStyles.AllPaintingInWmPaint |
                       ControlStyles.OptimizedDoubleBuffer |
                       ControlStyles.UserPaint, true);
              UpdateStyles();
          }
      }
  }